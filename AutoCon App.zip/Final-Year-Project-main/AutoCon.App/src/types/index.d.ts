export {};

declare global {
    interface Window {
        tronWeb: any;
        tronLink: any;
        sunWeb: any;
        ethereum: any
    }
}