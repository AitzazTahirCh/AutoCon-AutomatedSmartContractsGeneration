# Mentor notes

## UX
* Would be nice to implement some sort of flow diagram where functions can be created in the form of a flow chat.
* Backend not necessarily required, decouple generator logic to allow for building from other sources.

## UI
* not to hide things / ease of access, (obvious).
* pallet generators
* css variables
* lighter UI would be good.
* readability (borders are different colours).
* Dropdown with options (eliminate on type).
* simple description on help hover. On click open a broad description.